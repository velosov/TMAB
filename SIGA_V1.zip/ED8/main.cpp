#include <iostream>
using namespace std;

#define OTL_ODBC // Compile OTL 4.0/ODBC
#include "otlv4.h" // include the OTL 4.0 header file

otl_connect ConexaoAccess; // connect object

void selectTurmas(void)
{
    // Cria a "stream" de conexao com o banco
    otl_stream consulta1(200, // buffer size may be > 1
              "SELECT t.NoTurma, d.NomeDaDisciplina, t.Horario, t.Sala "
              "FROM Turma t INNER JOIN Disciplina d "
              "ON t.NoDisciplina = d.NoDisciplina",
              ConexaoAccess // connect object
             );
    int long noTurma;
    char disciplina[256];
    char horario[256];
    char sala[256];
    while(!consulta1.eof()){ // while not end-of-data
        consulta1 >> noTurma;
        consulta1 >> disciplina;
        consulta1 >> horario;
        consulta1 >> sala;
        cout << "| " << noTurma << " | " << disciplina << " | " << horario << " | " << sala << " |" << endl;
    }
}

void Inscricao(void)
{
    int noT;
    otl_stream cadastraInscricao(1, // buffer size may be > 1
              "INSERT INTO Inscricao "
              "VALUES ('244.691.811-', :turma<int>, 10 )",
              ConexaoAccess // connect object
             );

    selectTurmas();
    cout << "\n\t Escolha o numero de uma turma para se inscrever\n";
    cin >> noT;
    cadastraInscricao << noT;
}

int main()
{
    otl_connect::otl_initialize(); // initialize ODBC environment

    cout << "Estudo Dirigidos 8: Usando OTL 4.0/C++ para acessar o Access - MR2(c)/UFRJ" << endl;
    try{
        ConexaoAccess.rlogon("scott/tiger@siga2");
        Inscricao();
    }
    catch(otl_exception& p){ // intercept OTL exceptions
        cerr<<p.msg<<endl; // print out error message
        cerr<<p.stm_text<<endl; // print out SQL that caused the error
        cerr<<p.sqlstate<<endl; // print out SQLSTATE message
        cerr<<p.var_info<<endl; // print out the variable that caused the error
    }
    ConexaoAccess.logoff(); // disconnect from the database

    return 0;
}
