#ifndef TESTE_H
#define TESTE_H


class teste
{
    public:
        teste();
        virtual ~teste();

        unsigned int Getm_Counter() { return m_Counter; }
        void Setm_Counter(unsigned int val) { m_Counter = val; }

    protected:
        int a;
    private:
        unsigned int m_Counter;
};

#endif // TESTE_H
