#ifndef VIEW_H_INCLUDED
#define VIEW_H_INCLUDED

void ApresentaMenu(void);

#endif // VIEW_H_INCLUDED
