#ifndef MATRIZ_H
#define MATRIZ_H

#include <iostream>
#include <vector>
using namespace std;

class Matriz {

    unsigned m,n;
    //float a[100][100];
    vector< vector<float> > a;

 public:
    Matriz(unsigned=0, unsigned=0);// : m(pm), n(pn) {}
    Matriz(string);
    void Print(void);
    void GravaMatriz(string);
    Matriz operator +(Matriz B);
    Matriz operator -(Matriz B);
    Matriz operator *(Matriz B);
    vector<float> & operator [](int i) { return a[i]; }
    friend Matriz operator *(float esc, Matriz B);

};

class MTriSup : public Matriz
{
    float e;
public:
    MTriSup(int m, int n) : Matriz(m,n) {}
    void Print(void) { static int cnt = 0; cout << "TRI Superior:" << cnt++ << endl; Matriz::Print();}
};
#endif // MATRIZ_H
