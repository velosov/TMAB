#include <iostream>
using namespace std;

void ApresentaMenu(void)
{
    cout << "--------------------------------- ^.^ --" << endl;
    cout << "  1 - Carrega Matriz A." << endl;
    cout << "  2 - Carrega Matriz B." << endl;
    cout << "  3 - C = A + B." << endl;
    cout << "  4 - C = A - B." << endl;
    cout << "  5 - C = a * A." << endl;
    cout << "  6 - C = A x B." << endl;
    cout << "  7 - C = A^2." << endl;
    cout << "  8 - Sai do programa." << endl;

    cout << " \n  Digite uma opcao." << endl;
}
