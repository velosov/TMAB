#include <iostream>
#include "Matriz.h"
#include "view.h"

using namespace std;

void menu(void)
{
    char opcao;
    Matriz A,B,C;
    float escalar;

    do  {
        ApresentaMenu();
        cin >> opcao;
        switch (opcao)
        {
            case '1' : A = Matriz("A.mat"); A.Print(); break;
            case '2' : B = Matriz("B.mat"); B.Print(); break;
            case '3' : C = A + B; C.Print(); break;
            case '4' : C = A - B; C.Print(); break;
            case '5' : cout << "Escalar = "; cin >> escalar;
                       C = escalar * A; C.Print(); break;
            case '6' : C = A * B; C.Print(); break;
            case '7' : C = A*A; C.Print(); break;
            case '8' : cout << "Saindo....\n"; break;
            default  : cout << "\tOpcao Invalida!\n";
        }
    } while ( opcao != '8');
}

int main()
{
    cout << "Programa: Estudo Dirigido 03 - MR2(c)" << endl;
    MTriSup t1(3,3);
    Matriz C;

    C = 3.4*t1;
    t1.Print();
    C.Print();

    //menu();

    return 0;
}
