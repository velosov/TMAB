#include "../include/Matriz.h"
#include <fstream>

Matriz::Matriz(unsigned pm, unsigned pn)
{
    m = pm, n = pn;

    a.resize(m); // cria 'm' linhas
    for( unsigned i=0; i < m; i++)
        a[i].resize(n); // cria 'n' colunas em cada linha 'i'
}

Matriz::Matriz(string nome_arquivo_entrada)
{
    ifstream arq(nome_arquivo_entrada.c_str());

    if ( !arq.good() ) {
            cout << "problema ao abrir o arquivo: " << nome_arquivo_entrada << endl;
    }
    else {
        arq >> m >> n;
        a.resize(m); // cria 'm' linhas
        for( unsigned i=0; i < m; i++)
            a[i].resize(n); // cria 'n' colunas em cada linha 'i'
        for ( unsigned i = 0 ; i < m ; i++)
            for (unsigned j = 0; j < n; j++ ) arq >> a[i][j];
    }
}

Matriz Matriz::operator +(Matriz B)
{
    Matriz C;

    if ( m == B.m && n == B.n) { C = Matriz(m,n); }
    else {
        cout << "Matrizes soma incompativeis!" << endl;
        return C;
    }
    for ( unsigned i = 0 ; i < C.m ; i++)
        for (unsigned j = 0; j < C.n; j++ )
            C[i][j] = a[i][j] + B[i][j];
   return C;
}

Matriz Matriz::operator -(Matriz B)
{
    Matriz C;

    if ( m == B.m && n == B.n) { C = Matriz(m,n); }
    else {
        cout << "Matrizes soma incompativeis!" << endl;
        return C;
    }
    for ( unsigned i = 0 ; i < C.m ; i++)
        for (unsigned j = 0; j < C.n; j++ )
            C[i][j] = a[i][j] - B[i][j];
   return C;
}

Matriz Matriz::operator *(Matriz B)
{
    Matriz C;
    unsigned k;
    float cij;

    if ( n == B.m ) { C = Matriz(m,B.n); }
    else {
        cout << "Matrizes produto incompativeis!" << endl;
        return C;
    }
    for ( unsigned i = 0 ; i < C.m ; i++)
        for (unsigned j = 0; j < C.n; j++ )
        {
            for( k = 0, cij = 0.0; k < n; k++ )
                cij += a[i][k]*B[k][j];
            C[i][j] = cij;
        }
   return C;
}

void Matriz::Print(void)
{
    for ( unsigned i = 0 ; i < m ; i++) {
        for (unsigned j = 0; j < n; j++ ) cout << a[i][j] << " ";
        cout << endl;
    }
    cout << endl;
}

//----- Funcao do Model colocada aqui por pura pregui�a
Matriz operator *(float esc, Matriz B)
{
    Matriz C(B.m,B.n);

    for ( unsigned i = 0 ; i < C.m ; i++)
        for (unsigned j = 0; j < C.n; j++ )
            C[i][j] = esc * B[i][j];
   return C;
}
