#include "teste.h"

teste::teste()
{
    //ctor
}

teste::~teste()
{
    //dtor
}
