#include "ObjGrafico.h"
#include <sstream>

ObjGrafico::~ObjGrafico()
{
    //dtor
}

void ObjGrafico::Desenha(CTela & tela)
{
    std::stringstream str;

    str << "Objeto grafico no ponto (" << p.x << "," << p.y << ")" << endl;
    tela.grava(str.str());
}
