#include "Ponto2D.h"

Ponto2D::~Ponto2D()
{
    //dtor
}
