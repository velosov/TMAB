#include "linha.h"
#include <sstream>

Linha::~Linha()
{
    //dtor
}

void Linha::Desenha(CTela & tela)
{
    std::stringstream str;

    str << "<line ";
    str << "x1=\"" << p.x << "\" ";
    str << "y1=\"" << p.y << "\" ";
    str << "x2=\"" << p2.x << "\" ";
    str << "y2=\"" << p2.y << "\" ";
    str << "style=\"stroke:rgb(255,0,0);stroke-width:2\" /> ";
    str << endl;

    tela.grava(str.str());
}
