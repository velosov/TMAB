#include "CTela.h"

CTela::CTela(string arqHTML, unsigned tamX, unsigned tamY)
{
    html.open(arqHTML.c_str());

    html << "<!DOCTYPE html>" << endl;
    html << "<html>" << endl;
    html << "<body>" << endl;
    html << " <svg width=\"" << tamX << " \" height=\"" << tamY << " \"> " << endl;
}

CTela::~CTela()
{
    html << "</svg>" << endl;
    html << "</body>" << endl;
    html << "</html>" << endl;
    html.close();
}
