#include "Retangulo.h"
#include <sstream>
#include <cmath>

Retangulo::~Retangulo()
{
    //dtor
}

void Retangulo::Desenha(CTela & tela)
{
    std::stringstream str;

    str << "<rect "; //x="50" y="20" width="150" height="150"
    str << "x=\"" << p.x << "\" ";
    str << "y=\"" << p.y << "\" ";
    str << "width=\"" << abs(p2.x - p.x) << "\" ";
    str << "height=\"" << abs(p2.y - p.y) << "\" ";
    str << "style=\"stroke:rgb(0,0,255);stroke-width:2;fill-opacity:0.0\" /> ";
    str << endl;

    tela.grava(str.str());
}
