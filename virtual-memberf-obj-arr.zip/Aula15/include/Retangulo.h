#ifndef RETANGULO_H
#define RETANGULO_H

#include <ObjGrafico.h>


class Retangulo : public ObjGrafico
{
    public:
        Retangulo(Ponto2D mp1=Ponto2D(), Ponto2D mp2=Ponto2D()) : ObjGrafico(mp1), p2(mp2) {};
        ~Retangulo();
        void Desenha(CTela &);

        Ponto2D Getp2() { return p2; }
        void Setp2(Ponto2D val) { p2 = val; }

    protected:

    private:
        Ponto2D p2;
};

#endif // RETANGULO_H
