#ifndef CTELA_H
#define CTELA_H

#include <iostream>
#include <fstream>

using namespace std;

class CTela
{
    public:
        ofstream html;

        CTela(string arqHTML, unsigned, unsigned);
        ~CTela();

        void grava(string str) { html << str; };
};

#endif // CTELA_H
