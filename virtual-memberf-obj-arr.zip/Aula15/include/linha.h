#ifndef LINHA_H
#define LINHA_H

#include <ObjGrafico.h>

class Linha : public ObjGrafico
{
    public:
        Linha(Ponto2D mp2=Ponto2D()) : p2(mp2) {};
        Linha(Ponto2D mp1, Ponto2D mp2) : ObjGrafico(mp1) ,p2(mp2) {};
        ~Linha();
        void Desenha(CTela &);

        Ponto2D Getp2() { return p2; }
        void Setp2(Ponto2D val) { p2 = val; }

    private:
        Ponto2D p2;
};

#endif // LINHA_H
