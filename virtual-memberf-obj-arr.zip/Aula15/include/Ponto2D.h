#ifndef PONTO2D_H
#define PONTO2D_H

class Ponto2D
{
    public:
        Ponto2D(float mx=0, float my=0): x(mx), y(my) {};
        virtual ~Ponto2D();
        float x,y;
};

#endif // PONTO2D_H
