#ifndef OBJGRAFICO_H
#define OBJGRAFICO_H

#include <Ponto2D.h>
#include <CTela.h>

class ObjGrafico
{
    public:
        ObjGrafico(Ponto2D mp = Ponto2D(0,0)) : p(mp) {};
        ~ObjGrafico();
        virtual void Desenha(CTela & tela);

        Ponto2D p;
        unsigned cor;
        unsigned tam; // espessura do tra�o
};

#endif // OBJGRAFICO_H
