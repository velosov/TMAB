#include <iostream>
#include "../include/Ponto2D.h"
#include "../include/ObjGrafico.h"
#include "../include/linha.h"
#include "../include/Retangulo.h"
#include "../include/CTela.h"

#include <list>

using namespace std;

int main()
{
    cout << "Aula 15 - 14 de junho de 2016 - MR2(c)" << endl;

    CTela t1("tela01.html",200,200);
    CTela t2("tela02.html",300,300);

    Ponto2D p1,p2(10,55),p3(160,130);
    ObjGrafico og1;
    Linha l1,l2(p3),l3(p2,p3);
    Retangulo r1, r2(Ponto2D(), p3), r3(p2,p3);

    og1.Desenha(t1);

    // declarando um array de objetos graficos e inicializando com linhas e retangulos
    ObjGrafico * vObjsGraficos[20];
    vObjsGraficos[0] = &l1;
    vObjsGraficos[1] = &l2;
    vObjsGraficos[2] = &l3;
    vObjsGraficos[3] = &r1;
    vObjsGraficos[4] = &r2;
    vObjsGraficos[5] = &r3;

    // desenhando os objetos graficos do array
    for(unsigned i=0; i < 6; i++ ) vObjsGraficos[i]->Desenha(t1);


    list<ObjGrafico *> lista, ls2;
    Linha l4(Ponto2D(1,300),Ponto2D(300,1));

    cout << lista.size() << endl;
    lista.push_back(&l1);
    lista.push_back(&l2);
    lista.push_back(&r1);
    lista.push_back(&l4);
    cout << lista.size() << endl;

    ls2 = lista;
    for ( list<ObjGrafico *>::iterator it = ls2.begin();
          it != ls2.end(); ++it ) (*it)->Desenha(t2);

    return 0;
}
