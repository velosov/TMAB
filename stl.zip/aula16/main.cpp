#include <iostream>
#include <vector>
#include <list>

using namespace std;

class Ponto2D
{
    float x,y;
public:
    Ponto2D(float mx=0.0, float my=0.0) : x(mx), y(my) {}
    void print(void) { cout << "(" << x << "," << y << ") "; }
    ostream & print(ostream & out) { out << "(" << x << "," << y << ") "; return out;}
    friend ostream & operator <<(ostream & out, Ponto2D p );
};

ostream & operator <<(ostream & out, Ponto2D p )
{
    //out << "(" << p.x << "," << p.y << ") ";
    //return out;

    return p.print(out);
}

int main()
{

    cout << "Aula 16 - 21 de junho de 2016 - MR2(c)" << endl;

    cout << "Usando um VECTOR da STL\n";
    vector<Ponto2D> vPontos;
    cout << vPontos.size() << endl;
    vPontos.push_back(Ponto2D(10,10));
    vPontos.push_back(Ponto2D(100,200));
    vPontos.push_back(Ponto2D(1000,300));
    cout << vPontos.size() << endl;

    cout << "Percorrendo como estilo do C antigo\n";
    for( unsigned i=0; i < vPontos.size(); i++)
        cout << "Ponto [" << i << "] = " << vPontos[i] << endl;

    cout << "Percorrendo usando 'iterators' da STL\n";
    vector<Ponto2D>::iterator it;
    for( it = vPontos.begin(); it != vPontos.end(); ++it )
        cout << "Ponto [ x ] = " << *it << endl;

    cout << "Agora usando o LIST da STL\n";
    list<Ponto2D> lPontos;
    cout << lPontos.size() << endl;
    lPontos.push_back(Ponto2D(10,10));
    lPontos.push_back(Ponto2D(100,200));
    lPontos.push_back(Ponto2D(1000,300));
    cout << lPontos.size() << endl;

/*    cout << "Percorrendo como estilo do C antigo\n";
    for( unsigned i=0; i < lPontos.size(); i++)
        cout << "Ponto [" << i << "] = " << lPontos[i] << endl;
*/
    cout << "Percorrendo usando 'iterators' da STL\n";
    list<Ponto2D>::iterator itt;
    for( itt = lPontos.begin(); itt != lPontos.end(); ++itt )
        cout << "Ponto [ x ] = " << *itt << endl;



    return 0;}
