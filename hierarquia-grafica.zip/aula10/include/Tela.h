#ifndef TELA_H
#define TELA_H
#include <vector>

using namespace std;

class Tela
{
    vector<vector<char> > buffer;
public:
    unsigned Xmax;
    unsigned Ymax;
    Tela(unsigned txmax, unsigned tymax);
    void print(void);
    void Moldura(void);
    void putCharXY(int,int,char);
};

#endif // TELA_H
