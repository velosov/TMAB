#ifndef OBJGRAFICO_H
#define OBJGRAFICO_H

#include "Tela.h"

class ObjGrafico
{
    public:
        ObjGrafico();
        ~ObjGrafico();
        void Desenha(Tela & tela);

    protected:

    private:
};

class Ponto : public ObjGrafico
{
public:
    int x,y;

    Ponto(int xx=0, int yy=0) : x(xx), y(yy) {}
};

class Reta : public ObjGrafico
{
public:
    Ponto p;
    Reta (int px, int py) : p(px,py) {};
    Reta (Ponto pp) : p(pp) {};
    void Desenha(Tela & t);
};

class RHorizontal : public Reta
{
public:
    int extensaoX;
    RHorizontal(Ponto p0, int extX) : Reta(p0), extensaoX(extX) {}
    void Desenha(Tela & tela);
};

class Circulo : public ObjGrafico
{
public:
    Ponto C; // centro
    int raio;

    Circulo(Ponto centro, int p_raio) : C(centro), raio(p_raio) {}
    void Desenha(Tela &tela, char c);
};
#endif // OBJGRAFICO_H
