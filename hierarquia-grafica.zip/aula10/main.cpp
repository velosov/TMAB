#include <iostream>

#include "../include/ObjGrafico.h"

using namespace std;

int main()
{
    char c;

    cout << "Aula10 - Hierarquia de classes - TMAB 2016.1 - MR2(c)" << endl;

    Tela t1(99,39);
    t1.Moldura();

    Reta r(10,38);
    r.Desenha(t1);

    for ( int r = 5; r < 19; r += 4) {
        Circulo c1(Ponto(t1.Xmax/2,t1.Ymax/2),r);
        c1.Desenha(t1,'@');
    }

    RHorizontal rh(Ponto(10,5),30);
    rh.Desenha(t1);

    t1.print();
    cin >> c;

    return 0;
}
