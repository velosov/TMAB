#include "ObjGrafico.h"
#include <cmath>

ObjGrafico::ObjGrafico()
{
    //ctor
}

ObjGrafico::~ObjGrafico()
{
    //dtor
}

void Reta::Desenha(Tela & t)
{
}

void RHorizontal::Desenha(Tela & tela)
{
    for(int xt = 0; xt < extensaoX; xt++)
        tela.putCharXY(p.x + xt,p.y,'_');
}

void Circulo::Desenha(Tela & tela, char c)
{
    int angulo;
    int xt,yt;

    for ( angulo = 0; angulo < 360; angulo++ )
    {
        xt = round(C.x + raio*cos(angulo*M_PI/180));
        yt = round(C.y + raio*sin(angulo*M_PI/180));
        tela.putCharXY(xt,yt,c);
    }
}
