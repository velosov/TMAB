#include "Tela.h"
#include <iostream>

Tela::Tela(unsigned txmax, unsigned tymax)
{
    Xmax = txmax; Ymax = tymax;

    buffer.resize(Ymax);
    for(unsigned y=0; y < Ymax; y++) buffer[y].resize(Xmax);

    for(unsigned y=0; y < Ymax; y++)
        for(unsigned x=0; x < Xmax; x++)
            buffer[y][x] = ' ';
}

void Tela::Moldura(void)
{
    for(unsigned x = 0; x < Xmax; x++ ) buffer[0][x] = '#';
    for(unsigned y = 1; y < Ymax-1; y++) buffer[y][0] = buffer[y][Xmax-1] = '#';
    for(unsigned x = 0; x < Xmax; x++ ) buffer[Ymax-1][x] = '#';
}

void Tela::putCharXY(int xp,int yp,char c)
{
    buffer[yp][xp] = c;
}

void Tela::print(void)
{
    for(unsigned y=0; y < Ymax; y++) {
       for(unsigned x=0; x < Xmax; x++) cout << buffer[y][x];
       cout << endl;
    }
}

